#pragma once

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

void RelayController_Init(void);
void RelayController_Set(int index, bool on);
bool RelayController_Get(int index);

#ifdef __cplusplus
}
#endif
