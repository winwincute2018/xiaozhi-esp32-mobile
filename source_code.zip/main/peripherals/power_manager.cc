#include "power_manager.h"
#include "board_pins.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_log.h"

static adc_oneshot_unit_handle_t s_adc_handle = NULL;

void PowerManager_Init(void) {
    adc_oneshot_unit_init_config_t init_config = {
        .unit_id = ADC_UNIT_1,
    };
    adc_oneshot_new_unit(&init_config, &s_adc_handle);

    adc_oneshot_chan_cfg_t config = {
        .atten = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_DEFAULT,
    };
    adc_oneshot_config_channel(s_adc_handle, BATTERY_ADC_CHANNEL, &config);
}

int PowerManager_GetBatteryPercentage(void) {
    if (!s_adc_handle) return 100;
    int raw = 0;
    adc_oneshot_read(s_adc_handle, BATTERY_ADC_CHANNEL, &raw);

    // Chuyển đổi giá trị ADC thành % pin (ước lượng điện áp pin Li-po 3.3V - 4.2V)
    // Tỉ lệ phân áp R1=100k, R2=100k (1/2 điện áp pin)
    float voltage = (raw * 3.3f / 4095.0f) * 2.0f;
    int pct = (int)((voltage - 3.4f) / (4.2f - 3.4f) * 100.0f);
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    return pct;
}

bool PowerManager_IsCharging(void) {
    return false; // Có thể nối thêm chân GPIO CHRG của IC TP4056 nếu có
}
