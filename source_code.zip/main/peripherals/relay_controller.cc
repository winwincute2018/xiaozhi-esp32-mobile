#include "relay_controller.h"
#include "board_pins.h"
#include "driver/gpio.h"

static const gpio_num_t s_relays[3] = {RELAY_1_PIN, RELAY_2_PIN, RELAY_3_PIN};
static bool s_relay_states[3] = {false, false, false};

void RelayController_Init(void) {
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << RELAY_1_PIN) | (1ULL << RELAY_2_PIN) | (1ULL << RELAY_3_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io_conf);

    for (int i = 0; i < 3; i++) {
        gpio_set_level(s_relays[i], 0);
        s_relay_states[i] = false;
    }
}

void RelayController_Set(int index, bool on) {
    if (index >= 0 && index < 3) {
        s_relay_states[index] = on;
        gpio_set_level(s_relays[index], on ? 1 : 0);
    }
}

bool RelayController_Get(int index) {
    if (index >= 0 && index < 3) return s_relay_states[index];
    return false;
}
