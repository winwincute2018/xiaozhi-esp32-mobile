#pragma once

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void PowerManager_Init(void);
int PowerManager_GetBatteryPercentage(void);
bool PowerManager_IsCharging(void);

#ifdef __cplusplus
}
#endif
