#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    ASSISTANT_STATE_IDLE,
    ASSISTANT_STATE_LISTENING,
    ASSISTANT_STATE_THINKING,
    ASSISTANT_STATE_SPEAKING
} assistant_state_t;

// Khởi tạo toàn bộ giao diện Mobile UI
void UiMobile_Init(void);

// Cập nhật thanh trạng thái (Status Bar)
void UiMobile_SetTime(int hour, int minute);
void UiMobile_SetWifiStatus(bool connected, const char* ssid, int rssi);
void UiMobile_SetServerStatus(bool connected, const char* url);
void UiMobile_SetBattery(int percentage, bool is_charging);

// Cập nhật trạng thái Chatbot AI
void UiMobile_SetAssistantState(assistant_state_t state);
void UiMobile_SetUserSpeech(const char* text);
void UiMobile_SetAiResponse(const char* text);
void UiMobile_AppendAiResponse(const char* chunk);

// Cập nhật Widgets (Thời tiết & Trình phát nhạc)
void UiMobile_SetWeather(const char* city, int temp_c, const char* condition);
void UiMobile_SetMediaPlayback(const char* title, const char* artist, bool is_playing, int progress_percent);

// Cập nhật trạng thái Relay
void UiMobile_SetRelayState(int relay_index, bool state);

// Callbacks người dùng tương tác từ màn hình
typedef void (*ui_mic_btn_callback_t)(void);
typedef void (*ui_relay_toggle_callback_t)(int relay_index, bool state);
typedef void (*ui_slider_callback_t)(int value);

void UiMobile_RegisterMicCallback(ui_mic_btn_callback_t cb);
void UiMobile_RegisterRelayCallback(ui_relay_toggle_callback_t cb);
void UiMobile_RegisterVolumeCallback(ui_slider_callback_t cb);
void UiMobile_RegisterBrightnessCallback(ui_slider_callback_t cb);

// Hiển thị hướng dẫn cấu hình WiFi trên màn hình LCD
void UiMobile_ShowWifiSetupGuide(const char* ap_ssid, const char* ap_pass, const char* portal_ip);

#ifdef __cplusplus
}
#endif
