#pragma once

#include "lvgl.h"

/**
 * ============================================================================
 * BẢNG MÀU GIAO DIỆN HIỆN ĐẠI (MOBILE DARK THEME - iOS / MATERIAL STYLE)
 * ============================================================================
 */

#define COLOR_BG            lv_color_hex(0x101216)  // Nền tối sâu sang trọng
#define COLOR_SURFACE       lv_color_hex(0x1C1F26)  // Nền thẻ card / widget
#define COLOR_SURFACE_LIGHT lv_color_hex(0x282C37)  // Nền thẻ nổi
#define COLOR_PRIMARY       lv_color_hex(0x2979FF)  // Màu xanh dương chủ đạo
#define COLOR_ACCENT        lv_color_hex(0x00E676)  // Màu xanh ngọc (Active / Online)
#define COLOR_WARNING       lv_color_hex(0xFF9100)  // Màu cam cảnh báo
#define COLOR_DANGER        lv_color_hex(0xFF5252)  // Màu đỏ báo lỗi
#define COLOR_TEXT_MAIN     lv_color_hex(0xFFFFFF)  // Chữ trắng chính
#define COLOR_TEXT_MUTED    lv_color_hex(0x8E95A5)  // Chữ xám phụ

#define RADIUS_SM           8
#define RADIUS_MD           14
#define RADIUS_LG           20
