#include "ui_mobile.h"
#include "ui_theme.h"
#include <stdio.h>
#include <string.h>

// Các đối tượng LVGL
static lv_obj_t* s_screen_main = NULL;
static lv_obj_t* s_status_bar = NULL;
static lv_obj_t* s_lbl_time = NULL;
static lv_obj_t* s_lbl_wifi = NULL;
static lv_obj_t* s_lbl_server = NULL;
static lv_obj_t* s_lbl_battery = NULL;

static lv_obj_t* s_tabview = NULL;

// Tab 1: Chatbot AI
static lv_obj_t* s_tab_chat = NULL;
static lv_obj_t* s_avatar_circle = NULL;
static lv_obj_t* s_avatar_state_lbl = NULL;
static lv_obj_t* s_lbl_user_msg = NULL;
static lv_obj_t* s_lbl_ai_msg = NULL;
static lv_obj_t* s_btn_mic = NULL;
static lv_obj_t* s_lbl_mic_icon = NULL;

// Tab 2: Widgets
static lv_obj_t* s_tab_widgets = NULL;
static lv_obj_t* s_lbl_weather_temp = NULL;
static lv_obj_t* s_lbl_weather_info = NULL;
static lv_obj_t* s_lbl_music_title = NULL;
static lv_obj_t* s_lbl_music_artist = NULL;
static lv_obj_t* s_bar_music = NULL;
static lv_obj_t* s_btn_music_play = NULL;
static lv_obj_t* s_sw_relay[3] = {NULL, NULL, NULL};

// Tab 3: Settings
static lv_obj_t* s_tab_settings = NULL;
static lv_obj_t* s_slider_brightness = NULL;
static lv_obj_t* s_slider_volume = NULL;
static lv_obj_t* s_lbl_server_url = NULL;

// Callbacks
static ui_mic_btn_callback_t s_cb_mic = NULL;
static ui_relay_toggle_callback_t s_cb_relay = NULL;
static ui_slider_callback_t s_cb_vol = NULL;
static ui_slider_callback_t s_cb_bri = NULL;

// --- Sự kiện Touch ---
static void on_mic_btn_clicked(lv_event_t* e) {
    if (s_cb_mic) s_cb_mic();
}

static void on_relay_sw_changed(lv_event_t* e) {
    lv_obj_t* sw = lv_event_get_target(e);
    int idx = (int)(intptr_t)lv_event_get_user_data(e);
    bool state = lv_obj_has_state(sw, LV_STATE_CHECKED);
    if (s_cb_relay) s_cb_relay(idx, state);
}

static void on_vol_slider_changed(lv_event_t* e) {
    lv_obj_t* slider = lv_event_get_target(e);
    int val = lv_slider_get_value(slider);
    if (s_cb_vol) s_cb_vol(val);
}

static void on_bri_slider_changed(lv_event_t* e) {
    lv_obj_t* slider = lv_event_get_target(e);
    int val = lv_slider_get_value(slider);
    if (s_cb_bri) s_cb_bri(val);
}

// ============================================================================
// KHỞI TẠO THANH TRẠNG THÁI (STATUS BAR)
// ============================================================================
static void create_status_bar(lv_obj_t* parent) {
    s_status_bar = lv_obj_create(parent);
    lv_obj_set_size(s_status_bar, LV_PCT(100), 26);
    lv_obj_set_style_bg_color(s_status_bar, COLOR_BG, 0);
    lv_obj_set_style_border_width(s_status_bar, 0, 0);
    lv_obj_set_style_pad_all(s_status_bar, 4, 0);
    lv_obj_clear_flag(s_status_bar, LV_OBJ_FLAG_SCROLLABLE);

    // Thời gian bên trái
    s_lbl_time = lv_label_create(s_status_bar);
    lv_label_set_text(s_lbl_time, "12:00");
    lv_obj_set_style_text_color(s_lbl_time, COLOR_TEXT_MAIN, 0);
    lv_obj_align(s_lbl_time, LV_ALIGN_LEFT_MID, 6, 0);

    // Server icon
    s_lbl_server = lv_label_create(s_status_bar);
    lv_label_set_text(s_lbl_server, LV_SYMBOL_REFRESH);
    lv_obj_set_style_text_color(s_lbl_server, COLOR_ACCENT, 0);
    lv_obj_align(s_lbl_server, LV_ALIGN_RIGHT_MID, -60, 0);

    // Wi-Fi icon
    s_lbl_wifi = lv_label_create(s_status_bar);
    lv_label_set_text(s_lbl_wifi, LV_SYMBOL_WIFI);
    lv_obj_set_style_text_color(s_lbl_wifi, COLOR_TEXT_MAIN, 0);
    lv_obj_align(s_lbl_wifi, LV_ALIGN_RIGHT_MID, -36, 0);

    // Pin icon + text
    s_lbl_battery = lv_label_create(s_status_bar);
    lv_label_set_text(s_lbl_battery, LV_SYMBOL_BATTERY_FULL);
    lv_obj_set_style_text_color(s_lbl_battery, COLOR_ACCENT, 0);
    lv_obj_align(s_lbl_battery, LV_ALIGN_RIGHT_MID, -6, 0);
}

// ============================================================================
// TAB 1: MÀN HÌNH CHATBOT AI (AI COMPANION)
// ============================================================================
static void create_tab_chat(lv_obj_t* parent) {
    lv_obj_set_style_bg_color(parent, COLOR_BG, 0);
    lv_obj_set_style_pad_all(parent, 10, 0);

    // 1. Avatar AI Face (Vòng tròn phát sáng đổi màu theo trạng thái)
    s_avatar_circle = lv_obj_create(parent);
    lv_obj_set_size(s_avatar_circle, 80, 80);
    lv_obj_set_style_radius(s_avatar_circle, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_color(s_avatar_circle, COLOR_SURFACE, 0);
    lv_obj_set_style_border_color(s_avatar_circle, COLOR_PRIMARY, 0);
    lv_obj_set_style_border_width(s_avatar_circle, 3, 0);
    lv_obj_align(s_avatar_circle, LV_ALIGN_TOP_MID, 0, 5);

    s_avatar_state_lbl = lv_label_create(s_avatar_circle);
    lv_label_set_text(s_avatar_state_lbl, "AI");
    lv_obj_set_style_text_color(s_avatar_state_lbl, COLOR_PRIMARY, 0);
    lv_obj_center(s_avatar_state_lbl);

    // 2. Bong bóng lời thoại của User (Right-aligned, Blue)
    s_lbl_user_msg = lv_label_create(parent);
    lv_label_set_text(s_lbl_user_msg, "Bấm nút Micro để nói chuyện...");
    lv_obj_set_width(s_lbl_user_msg, 210);
    lv_label_set_long_mode(s_lbl_user_msg, LV_LABEL_LONG_WRAP);
    lv_obj_set_style_bg_color(s_lbl_user_msg, COLOR_PRIMARY, 0);
    lv_obj_set_style_bg_opa(s_lbl_user_msg, LV_OPA_COVER, 0);
    lv_obj_set_style_text_color(s_lbl_user_msg, COLOR_TEXT_MAIN, 0);
    lv_obj_set_style_pad_all(s_lbl_user_msg, 8, 0);
    lv_obj_set_style_radius(s_lbl_user_msg, RADIUS_MD, 0);
    lv_obj_align(s_lbl_user_msg, LV_ALIGN_TOP_RIGHT, 0, 95);

    // 3. Bong bóng phản hồi của AI (Left-aligned, Dark Surface)
    s_lbl_ai_msg = lv_label_create(parent);
    lv_label_set_text(s_lbl_ai_msg, "Xin chào! Tôi là trợ lý ảo Xiaozhi. Tôi có thể giúp gì cho bạn?");
    lv_obj_set_width(s_lbl_ai_msg, 210);
    lv_label_set_long_mode(s_lbl_ai_msg, LV_LABEL_LONG_WRAP);
    lv_obj_set_style_bg_color(s_lbl_ai_msg, COLOR_SURFACE, 0);
    lv_obj_set_style_bg_opa(s_lbl_ai_msg, LV_OPA_COVER, 0);
    lv_obj_set_style_text_color(s_lbl_ai_msg, COLOR_TEXT_MAIN, 0);
    lv_obj_set_style_pad_all(s_lbl_ai_msg, 8, 0);
    lv_obj_set_style_radius(s_lbl_ai_msg, RADIUS_MD, 0);
    lv_obj_align(s_lbl_ai_msg, LV_ALIGN_TOP_LEFT, 0, 145);

    // 4. Nút bấm Micro nổi (Floating Action Button)
    s_btn_mic = lv_btn_create(parent);
    lv_obj_set_size(s_btn_mic, 48, 48);
    lv_obj_set_style_radius(s_btn_mic, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_color(s_btn_mic, COLOR_PRIMARY, 0);
    lv_obj_align(s_btn_mic, LV_ALIGN_BOTTOM_MID, 0, -5);
    lv_obj_add_event_cb(s_btn_mic, on_mic_btn_clicked, LV_EVENT_CLICKED, NULL);

    s_lbl_mic_icon = lv_label_create(s_btn_mic);
    lv_label_set_text(s_lbl_mic_icon, LV_SYMBOL_AUDIO);
    lv_obj_set_style_text_color(s_lbl_mic_icon, COLOR_TEXT_MAIN, 0);
    lv_obj_center(s_lbl_mic_icon);
}

// ============================================================================
// TAB 2: MÀN HÌNH WIDGETS & SMART HOME
// ============================================================================
static void create_tab_widgets(lv_obj_t* parent) {
    lv_obj_set_style_bg_color(parent, COLOR_BG, 0);
    lv_obj_set_style_pad_all(parent, 8, 0);

    // --- Card 1: Thời tiết ---
    lv_obj_t* card_weather = lv_obj_create(parent);
    lv_obj_set_size(card_weather, LV_PCT(100), 65);
    lv_obj_set_style_bg_color(card_weather, COLOR_SURFACE, 0);
    lv_obj_set_style_border_width(card_weather, 0, 0);
    lv_obj_set_style_radius(card_weather, RADIUS_MD, 0);
    lv_obj_align(card_weather, LV_ALIGN_TOP_MID, 0, 0);
    lv_obj_clear_flag(card_weather, LV_OBJ_FLAG_SCROLLABLE);

    s_lbl_weather_temp = lv_label_create(card_weather);
    lv_label_set_text(s_lbl_weather_temp, "28°C");
    lv_obj_set_style_text_color(s_lbl_weather_temp, COLOR_PRIMARY, 0);
    lv_obj_align(s_lbl_weather_temp, LV_ALIGN_LEFT_MID, 4, 0);

    s_lbl_weather_info = lv_label_create(card_weather);
    lv_label_set_text(s_lbl_weather_info, "Hà Nội - Nắng đẹp");
    lv_obj_set_style_text_color(s_lbl_weather_info, COLOR_TEXT_MUTED, 0);
    lv_obj_align(s_lbl_weather_info, LV_ALIGN_LEFT_MID, 55, 0);

    // --- Card 2: Trình phát nhạc / Radio ---
    lv_obj_t* card_media = lv_obj_create(parent);
    lv_obj_set_size(card_media, LV_PCT(100), 75);
    lv_obj_set_style_bg_color(card_media, COLOR_SURFACE, 0);
    lv_obj_set_style_border_width(card_media, 0, 0);
    lv_obj_set_style_radius(card_media, RADIUS_MD, 0);
    lv_obj_align(card_media, LV_ALIGN_TOP_MID, 0, 72);
    lv_obj_clear_flag(card_media, LV_OBJ_FLAG_SCROLLABLE);

    s_lbl_music_title = lv_label_create(card_media);
    lv_label_set_text(s_lbl_music_title, "Đang phát: VOV Giao Thông");
    lv_obj_set_style_text_color(s_lbl_music_title, COLOR_TEXT_MAIN, 0);
    lv_obj_align(s_lbl_music_title, LV_ALIGN_TOP_LEFT, 2, 2);

    s_lbl_music_artist = lv_label_create(card_media);
    lv_label_set_text(s_lbl_music_artist, "Kênh Radio Trực Tuyến");
    lv_obj_set_style_text_color(s_lbl_music_artist, COLOR_TEXT_MUTED, 0);
    lv_obj_align(s_lbl_music_artist, LV_ALIGN_TOP_LEFT, 2, 20);

    s_bar_music = lv_bar_create(card_media);
    lv_obj_set_size(s_bar_music, 180, 6);
    lv_obj_align(s_bar_music, LV_ALIGN_BOTTOM_LEFT, 2, -6);
    lv_bar_set_value(s_bar_music, 45, LV_ANIM_OFF);

    // --- Card 3: Điều khiển Relay / Nhà thông minh ---
    lv_obj_t* card_home = lv_obj_create(parent);
    lv_obj_set_size(card_home, LV_PCT(100), 80);
    lv_obj_set_style_bg_color(card_home, COLOR_SURFACE, 0);
    lv_obj_set_style_border_width(card_home, 0, 0);
    lv_obj_set_style_radius(card_home, RADIUS_MD, 0);
    lv_obj_align(card_home, LV_ALIGN_TOP_MID, 0, 154);
    lv_obj_clear_flag(card_home, LV_OBJ_FLAG_SCROLLABLE);

    const char* relay_names[3] = {"Đèn", "Quạt", "Phụ"};
    for (int i = 0; i < 3; i++) {
        lv_obj_t* lbl = lv_label_create(card_home);
        lv_label_set_text(lbl, relay_names[i]);
        lv_obj_set_style_text_color(lbl, COLOR_TEXT_MAIN, 0);
        lv_obj_align(lbl, LV_ALIGN_TOP_LEFT, i * 72 + 6, 2);

        s_sw_relay[i] = lv_switch_create(card_home);
        lv_obj_set_size(s_sw_relay[i], 46, 24);
        lv_obj_align(s_sw_relay[i], LV_ALIGN_TOP_LEFT, i * 72, 25);
        lv_obj_add_event_cb(s_sw_relay[i], on_relay_sw_changed, LV_EVENT_VALUE_CHANGED, (void*)(intptr_t)i);
    }
}

// ============================================================================
// TAB 3: MÀN HÌNH CÀI ĐẶT (SETTINGS)
// ============================================================================
static void create_tab_settings(lv_obj_t* parent) {
    lv_obj_set_style_bg_color(parent, COLOR_BG, 0);
    lv_obj_set_style_pad_all(parent, 10, 0);

    // 1. Thanh kéo độ sáng màn hình
    lv_obj_t* lbl_b = lv_label_create(parent);
    lv_label_set_text(lbl_b, LV_SYMBOL_EYE_OPEN "  Độ sáng màn hình:");
    lv_obj_set_style_text_color(lbl_b, COLOR_TEXT_MAIN, 0);
    lv_obj_align(lbl_b, LV_ALIGN_TOP_LEFT, 0, 0);

    s_slider_brightness = lv_slider_create(parent);
    lv_obj_set_size(s_slider_brightness, LV_PCT(100), 12);
    lv_slider_set_range(s_slider_brightness, 10, 100);
    lv_slider_set_value(s_slider_brightness, 80, LV_ANIM_OFF);
    lv_obj_align(s_slider_brightness, LV_ALIGN_TOP_MID, 0, 24);
    lv_obj_add_event_cb(s_slider_brightness, on_bri_slider_changed, LV_EVENT_VALUE_CHANGED, NULL);

    // 2. Thanh kéo âm lượng loa
    lv_obj_t* lbl_v = lv_label_create(parent);
    lv_label_set_text(lbl_v, LV_SYMBOL_VOLUME_MAX "  Âm lượng loa:");
    lv_obj_set_style_text_color(lbl_v, COLOR_TEXT_MAIN, 0);
    lv_obj_align(lbl_v, LV_ALIGN_TOP_LEFT, 0, 50);

    s_slider_volume = lv_slider_create(parent);
    lv_obj_set_size(s_slider_volume, LV_PCT(100), 12);
    lv_slider_set_range(s_slider_volume, 0, 100);
    lv_slider_set_value(s_slider_volume, 70, LV_ANIM_OFF);
    lv_obj_align(s_slider_volume, LV_ALIGN_TOP_MID, 0, 74);
    lv_obj_add_event_cb(s_slider_volume, on_vol_slider_changed, LV_EVENT_VALUE_CHANGED, NULL);

    // 3. Thông tin Server & Hệ thống
    lv_obj_t* card_info = lv_obj_create(parent);
    lv_obj_set_size(card_info, LV_PCT(100), 95);
    lv_obj_set_style_bg_color(card_info, COLOR_SURFACE, 0);
    lv_obj_set_style_border_width(card_info, 0, 0);
    lv_obj_set_style_radius(card_info, RADIUS_MD, 0);
    lv_obj_align(card_info, LV_ALIGN_TOP_MID, 0, 105);
    lv_obj_clear_flag(card_info, LV_OBJ_FLAG_SCROLLABLE);

    s_lbl_server_url = lv_label_create(card_info);
    lv_label_set_text(s_lbl_server_url, "Server: ws://192.168.1.100:8000/ws");
    lv_obj_set_style_text_color(s_lbl_server_url, COLOR_PRIMARY, 0);
    lv_obj_align(s_lbl_server_url, LV_ALIGN_TOP_LEFT, 0, 0);

    lv_obj_t* lbl_lic = lv_label_create(card_info);
    lv_label_set_text(lbl_lic, "Bản quyền: VĨNH VIỄN (Open Edition)");
    lv_obj_set_style_text_color(lbl_lic, COLOR_ACCENT, 0);
    lv_obj_align(lbl_lic, LV_ALIGN_TOP_LEFT, 0, 24);

    lv_obj_t* lbl_fw = lv_label_create(card_info);
    lv_label_set_text(lbl_fw, "Firmware: Xiaozhi OS v2.0 Clean");
    lv_obj_set_style_text_color(lbl_fw, COLOR_TEXT_MUTED, 0);
    lv_obj_align(lbl_fw, LV_ALIGN_TOP_LEFT, 0, 48);
}

// ============================================================================
// KHỞI TẠO TỔNG THỂ MOBILE UI
// ============================================================================
void UiMobile_Init(void) {
    s_screen_main = lv_scr_act();
    lv_obj_set_style_bg_color(s_screen_main, COLOR_BG, 0);

    // 1. Tạo Status Bar trên cùng
    create_status_bar(s_screen_main);

    // 2. Tạo Tabview chia 3 màn hình dạng vuốt trượt
    s_tabview = lv_tabview_create(s_screen_main, LV_DIR_BOTTOM, 36);
    lv_obj_set_size(s_tabview, LV_PCT(100), 294);
    lv_obj_align(s_tabview, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_obj_set_style_bg_color(s_tabview, COLOR_BG, 0);

    // 3. Khởi tạo 3 Tab
    s_tab_chat     = lv_tabview_add_tab(s_tabview, LV_SYMBOL_AUDIO " Chat");
    s_tab_widgets  = lv_tabview_add_tab(s_tabview, LV_SYMBOL_HOME " Tiện ích");
    s_tab_settings = lv_tabview_add_tab(s_tabview, LV_SYMBOL_SETTINGS " Cài đặt");

    create_tab_chat(s_tab_chat);
    create_tab_widgets(s_tab_widgets);
    create_tab_settings(s_tab_settings);
}

// ============================================================================
// CÁC HÀM CẬP NHẬT GIAO DIỆN REALTIME TỪ CORE BACKEND
// ============================================================================
void UiMobile_SetTime(int hour, int minute) {
    if (!s_lbl_time) return;
    char buf[16];
    snprintf(buf, sizeof(buf), "%02d:%02d", hour, minute);
    lv_label_set_text(s_lbl_time, buf);
}

void UiMobile_SetWifiStatus(bool connected, const char* ssid, int rssi) {
    if (!s_lbl_wifi) return;
    lv_obj_set_style_text_color(s_lbl_wifi, connected ? COLOR_ACCENT : COLOR_DANGER, 0);
}

void UiMobile_SetServerStatus(bool connected, const char* url) {
    if (!s_lbl_server) return;
    lv_obj_set_style_text_color(s_lbl_server, connected ? COLOR_ACCENT : COLOR_DANGER, 0);
    if (s_lbl_server_url && url) {
        char buf[80];
        snprintf(buf, sizeof(buf), "Server: %s", url);
        lv_label_set_text(s_lbl_server_url, buf);
    }
}

void UiMobile_SetBattery(int percentage, bool is_charging) {
    if (!s_lbl_battery) return;
    const char* sym = LV_SYMBOL_BATTERY_FULL;
    if (percentage < 20) sym = LV_SYMBOL_BATTERY_EMPTY;
    else if (percentage < 50) sym = LV_SYMBOL_BATTERY_1;
    else if (percentage < 75) sym = LV_SYMBOL_BATTERY_2;
    else if (percentage < 90) sym = LV_SYMBOL_BATTERY_3;

    lv_label_set_text(s_lbl_battery, sym);
}

void UiMobile_SetAssistantState(assistant_state_t state) {
    if (!s_avatar_circle || !s_avatar_state_lbl) return;

    switch (state) {
        case ASSISTANT_STATE_IDLE:
            lv_obj_set_style_border_color(s_avatar_circle, COLOR_PRIMARY, 0);
            lv_label_set_text(s_avatar_state_lbl, "AI");
            break;
        case ASSISTANT_STATE_LISTENING:
            lv_obj_set_style_border_color(s_avatar_circle, COLOR_ACCENT, 0);
            lv_label_set_text(s_avatar_state_lbl, "ĐANG NGHE");
            break;
        case ASSISTANT_STATE_THINKING:
            lv_obj_set_style_border_color(s_avatar_circle, COLOR_WARNING, 0);
            lv_label_set_text(s_avatar_state_lbl, "ĐANG NGHĨ");
            break;
        case ASSISTANT_STATE_SPEAKING:
            lv_obj_set_style_border_color(s_avatar_circle, lv_color_hex(0xE040FB), 0);
            lv_label_set_text(s_avatar_state_lbl, "TRẢ LỜI");
            break;
    }
}

void UiMobile_SetUserSpeech(const char* text) {
    if (!s_lbl_user_msg || !text) return;
    lv_label_set_text(s_lbl_user_msg, text);
}

void UiMobile_SetAiResponse(const char* text) {
    if (!s_lbl_ai_msg || !text) return;
    lv_label_set_text(s_lbl_ai_msg, text);
}

void UiMobile_AppendAiResponse(const char* chunk) {
    if (!s_lbl_ai_msg || !chunk) return;
    // Nối thêm text khi LLM stream về
    char buf[512];
    snprintf(buf, sizeof(buf), "%s%s", lv_label_get_text(s_lbl_ai_msg), chunk);
    lv_label_set_text(s_lbl_ai_msg, buf);
}

void UiMobile_SetWeather(const char* city, int temp_c, const char* condition) {
    if (s_lbl_weather_temp) {
        char buf[16];
        snprintf(buf, sizeof(buf), "%d°C", temp_c);
        lv_label_set_text(s_lbl_weather_temp, buf);
    }
    if (s_lbl_weather_info) {
        char buf[64];
        snprintf(buf, sizeof(buf), "%s - %s", city ? city : "Việt Nam", condition ? condition : "Thời tiết");
        lv_label_set_text(s_lbl_weather_info, buf);
    }
}

void UiMobile_SetMediaPlayback(const char* title, const char* artist, bool is_playing, int progress_percent) {
    if (s_lbl_music_title && title) lv_label_set_text(s_lbl_music_title, title);
    if (s_lbl_music_artist && artist) lv_label_set_text(s_lbl_music_artist, artist);
    if (s_bar_music) lv_bar_set_value(s_bar_music, progress_percent, LV_ANIM_ON);
}

void UiMobile_SetRelayState(int relay_index, bool state) {
    if (relay_index >= 0 && relay_index < 3 && s_sw_relay[relay_index]) {
        if (state) lv_obj_add_state(s_sw_relay[relay_index], LV_STATE_CHECKED);
        else lv_obj_clear_state(s_sw_relay[relay_index], LV_STATE_CHECKED);
    }
}

// Đăng ký callbacks
void UiMobile_RegisterMicCallback(ui_mic_btn_callback_t cb) { s_cb_mic = cb; }
void UiMobile_RegisterRelayCallback(ui_relay_toggle_callback_t cb) { s_cb_relay = cb; }
void UiMobile_RegisterVolumeCallback(ui_slider_callback_t cb) { s_cb_vol = cb; }
void UiMobile_RegisterBrightnessCallback(ui_slider_callback_t cb) { s_cb_bri = cb; }
