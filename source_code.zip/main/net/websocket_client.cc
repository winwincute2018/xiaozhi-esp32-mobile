#include "websocket_client.h"
#include "audio/es8311_codec.h"
#include "ui/ui_mobile.h"
#include "peripherals/relay_controller.h"

#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_websocket_client.h"
#include "esp_log.h"
#include "cJSON.h"

static const char* TAG = "WSClient";

static esp_websocket_client_handle_t s_ws_client = NULL;
static bool s_ws_connected = false;
static bool s_is_listening = false;
static TaskHandle_t s_mic_task_handle = NULL;

// --- Tác vụ thu âm micro và gửi audio frames lên WebSocket ---
static void mic_stream_task(void *pvParameters) {
    int16_t pcm_buf[320]; // 20ms audio frame ở 16kHz
    while (s_is_listening && s_ws_connected) {
        int samples = Es8311_Read(pcm_buf, 320);
        if (samples > 0 && esp_websocket_client_is_connected(s_ws_client)) {
            esp_websocket_client_send_bin(s_ws_client, (char*)pcm_buf, samples * sizeof(int16_t), pdMS_TO_TICKS(50));
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    vTaskDelete(NULL);
}

// --- Xử lý gói tin JSON nhận được từ Server ---
static void handle_json_message(const char* json_str) {
    cJSON* root = cJSON_Parse(json_str);
    if (!root) return;

    cJSON* type_item = cJSON_GetObjectItem(root, "type");
    if (type_item && cJSON_IsString(type_item)) {
        const char* type = type_item->valuestring;

        if (strcmp(type, "hello") == 0) {
            ESP_LOGI(TAG, "Server Handshake OK!");
            UiMobile_SetServerStatus(true, NULL);
            UiMobile_SetAssistantState(ASSISTANT_STATE_IDLE);
        }
        else if (strcmp(type, "stt") == 0) {
            cJSON* text_item = cJSON_GetObjectItem(root, "text");
            if (text_item && cJSON_IsString(text_item)) {
                UiMobile_SetUserSpeech(text_item->valuestring);
                UiMobile_SetAssistantState(ASSISTANT_STATE_THINKING);
            }
        }
        else if (strcmp(type, "tts") == 0) {
            cJSON* state_item = cJSON_GetObjectItem(root, "state");
            if (state_item && cJSON_IsString(state_item)) {
                if (strcmp(state_item->valuestring, "start") == 0) {
                    UiMobile_SetAssistantState(ASSISTANT_STATE_SPEAKING);
                } else if (strcmp(state_item->valuestring, "stop") == 0) {
                    UiMobile_SetAssistantState(ASSISTANT_STATE_IDLE);
                }
            }
            cJSON* text_item = cJSON_GetObjectItem(root, "text");
            if (text_item && cJSON_IsString(text_item)) {
                UiMobile_SetAiResponse(text_item->valuestring);
            }
        }
        else if (strcmp(type, "mcp") == 0) {
            // Xử lý Tool Call: Bật tắt relay, thời tiết, phát nhạc
            cJSON* payload = cJSON_GetObjectItem(root, "payload");
            if (payload) {
                cJSON* tool_name = cJSON_GetObjectItem(payload, "name");
                cJSON* args = cJSON_GetObjectItem(payload, "arguments");
                if (tool_name && cJSON_IsString(tool_name)) {
                    if (strstr(tool_name->valuestring, "relay")) {
                        cJSON* r_idx = cJSON_GetObjectItem(args, "index");
                        cJSON* r_st = cJSON_GetObjectItem(args, "state");
                        if (r_idx && r_st) {
                            RelayController_Set(r_idx->valueint, cJSON_IsTrue(r_st));
                            UiMobile_SetRelayState(r_idx->valueint, cJSON_IsTrue(r_st));
                        }
                    }
                }
            }
        }
    }
    cJSON_Delete(root);
}

// --- Xử lý sự kiện WebSocket ---
static void websocket_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data) {
    esp_websocket_event_data_t *data = (esp_websocket_event_data_t *)event_data;
    switch (event_id) {
        case WEBSOCKET_EVENT_CONNECTED:
            ESP_LOGI(TAG, "WEBSOCKET_EVENT_CONNECTED");
            s_ws_connected = true;
            UiMobile_SetServerStatus(true, NULL);

            // Gửi gói Handshake Hello
            {
                const char* hello_msg = "{\"type\":\"hello\",\"version\":1,\"transport\":\"websocket\",\"audio_params\":{\"format\":\"pcm\",\"sample_rate\":16000,\"channels\":1}}";
                esp_websocket_client_send_text(s_ws_client, hello_msg, strlen(hello_msg), pdMS_TO_TICKS(100));
            }
            break;

        case WEBSOCKET_EVENT_DISCONNECTED:
            ESP_LOGW(TAG, "WEBSOCKET_EVENT_DISCONNECTED");
            s_ws_connected = false;
            UiMobile_SetServerStatus(false, NULL);
            break;

        case WEBSOCKET_EVENT_DATA:
            if (data->op_code == 0x01) { // Text JSON
                char* text = (char*)malloc(data->data_len + 1);
                memcpy(text, data->data_ptr, data->data_len);
                text[data->data_len] = '\0';
                handle_json_message(text);
                free(text);
            } else if (data->op_code == 0x02) { // Binary Audio (PCM/Opus stream từ TTS về)
                Es8311_Write((const int16_t*)data->data_ptr, data->data_len / sizeof(int16_t));
            }
            break;

        case WEBSOCKET_EVENT_ERROR:
            ESP_LOGE(TAG, "WEBSOCKET_EVENT_ERROR");
            break;
    }
}

void WebSocketClient_Init(const std::string& server_url) {
    esp_websocket_client_config_t ws_cfg = {};
    ws_cfg.uri = server_url.c_str();
    ws_cfg.buffer_size = 4096;
    ws_cfg.reconnect_timeout_ms = 5000;

    s_ws_client = esp_websocket_client_init(&ws_cfg);
    esp_websocket_register_events(s_ws_client, WEBSOCKET_EVENT_ANY, websocket_event_handler, (void *)s_ws_client);
    esp_websocket_client_start(s_ws_client);
}

void WebSocketClient_StartListening(void) {
    if (!s_ws_connected || s_is_listening) return;
    s_is_listening = true;
    UiMobile_SetAssistantState(ASSISTANT_STATE_LISTENING);
    UiMobile_SetUserSpeech("Đang lắng nghe bạn...");

    // Báo Server bắt đầu phiên nghe
    const char* start_msg = "{\"type\":\"listen\",\"state\":\"start\"}";
    esp_websocket_client_send_text(s_ws_client, start_msg, strlen(start_msg), pdMS_TO_TICKS(100));

    // Khởi tạo tác vụ thu âm mic stream
    xTaskCreatePinnedToCore(mic_stream_task, "mic_stream", 4096, NULL, 5, &s_mic_task_handle, 0);
}

void WebSocketClient_StopListening(void) {
    if (!s_is_listening) return;
    s_is_listening = false;
    UiMobile_SetAssistantState(ASSISTANT_STATE_THINKING);

    const char* stop_msg = "{\"type\":\"listen\",\"state\":\"stop\"}";
    esp_websocket_client_send_text(s_ws_client, stop_msg, strlen(stop_msg), pdMS_TO_TICKS(100));
}

bool WebSocketClient_IsListening(void) { return s_is_listening; }
bool WebSocketClient_IsConnected(void) { return s_ws_connected; }
