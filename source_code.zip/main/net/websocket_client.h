#pragma once

#include <stdbool.h>
#include <string>

#ifdef __cplusplus
extern "C" {
#endif

// Khởi tạo và kết nối WebSocket tới Server riêng
void WebSocketClient_Init(const std::string& server_url);

// Bắt đầu / Dừng chế độ lắng nghe (Thu âm từ Mic gửi lên Server)
void WebSocketClient_StartListening(void);
void WebSocketClient_StopListening(void);
bool WebSocketClient_IsListening(void);

// Trạng thái kết nối
bool WebSocketClient_IsConnected(void);

#ifdef __cplusplus
}
#endif
