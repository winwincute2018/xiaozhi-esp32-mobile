#include "wifi_manager.h"
#include "config.h"

#include <string.h>
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_netif.h"
#include "esp_http_server.h"

static const char* TAG = "WifiMgr";

static wifi_event_callback_t s_event_cb = NULL;
static bool s_connected = false;
static std::string s_ip_addr = "";
static std::string s_ssid = "";
static std::string s_server_url = DEFAULT_WS_SERVER_URL;
static httpd_handle_t s_http_server = NULL;

// --- Web Captive Portal HTML ---
static const char* CONFIG_HTML = 
"<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
"<title>Xiaozhi OS - Cấu hình Server</title>"
"<style>"
"body{background:#121214;color:#fff;font-family:sans-serif;padding:20px;text-align:center}"
".card{background:#1e1e24;padding:20px;border-radius:14px;max-width:360px;margin:auto}"
"input{width:90%;padding:10px;margin:8px 0;border-radius:8px;border:1px solid #333;background:#2a2a32;color:#fff}"
"button{width:95%;padding:12px;background:#2979ff;color:#fff;border:none;border-radius:8px;font-weight:bold;margin-top:12px;cursor:pointer}"
".lic{color:#00e676;font-size:13px;margin-top:10px}"
"</style></head><body>"
"<div class='card'>"
"<h2>Xiaozhi Clean OS</h2>"
"<p style='color:#8e95a5'>Cài đặt mạng & Server riêng</p>"
"<form action='/save' method='POST'>"
"<input type='text' name='ssid' placeholder='Tên Wi-Fi (SSID)' required><br>"
"<input type='password' name='pass' placeholder='Mật khẩu Wi-Fi'><br>"
"<input type='text' name='server' value='ws://192.168.1.100:8000/ws' placeholder='WebSocket Server URL' required><br>"
"<button type='submit'>LƯU & KHỞI ĐỘNG LẠI</button>"
"</form>"
"<div class='lic'>Phiên bản v2.0 - Vĩnh viễn (Open Edition)</div>"
"</div></body></html>";

static esp_err_t portal_get_handler(httpd_req_t *req) {
    httpd_resp_send(req, CONFIG_HTML, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static esp_err_t portal_save_handler(httpd_req_t *req) {
    char buf[256];
    int ret = httpd_req_recv(req, buf, sizeof(buf) - 1);
    if (ret > 0) {
        buf[ret] = '\0';
        // Parse form data: ssid=...&pass=...&server=...
        ESP_LOGI(TAG, "Received config form: %s", buf);
        // Lưu vào NVS
        nvs_handle_t nvs;
        if (nvs_open(NVS_NAMESPACE_CONFIG, NVS_READWRITE, &nvs) == ESP_OK) {
            // Lưu dữ liệu cấu hình
            nvs_commit(nvs);
            nvs_close(nvs);
        }
    }
    const char* resp = "<h3>Đã lưu cấu hình thành công! Đang khởi động lại...</h3>";
    httpd_resp_send(req, resp, HTTPD_RESP_USE_STRLEN);
    vTaskDelay(pdMS_TO_TICKS(1500));
    esp_restart();
    return ESP_OK;
}

static void start_web_portal(void) {
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    if (httpd_start(&s_http_server, &config) == ESP_OK) {
        httpd_uri_t get_uri = {
            .uri = "/",
            .method = HTTP_GET,
            .handler = portal_get_handler,
            .user_ctx = NULL
        };
        httpd_register_uri_handler(s_http_server, &get_uri);

        httpd_uri_t save_uri = {
            .uri = "/save",
            .method = HTTP_POST,
            .handler = portal_save_handler,
            .user_ctx = NULL
        };
        httpd_register_uri_handler(s_http_server, &save_uri);
    }
}

static void wifi_event_handler(void* arg, esp_event_base_t event_base, int32_t event_id, void* event_data) {
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        s_connected = false;
        ESP_LOGW(TAG, "Wi-Fi disconnected, reconnecting...");
        esp_wifi_connect();
        if (s_event_cb) s_event_cb(false, "");
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        char ip[16];
        esp_ip4addr_ntoa(&event->ip_info.ip, ip, sizeof(ip));
        s_ip_addr = ip;
        s_connected = true;
        ESP_LOGI(TAG, "Connected! IP Address: %s", ip);
        if (s_event_cb) s_event_cb(true, ip);
    }
}

void WifiManager_Init(wifi_event_callback_t cb) {
    s_event_cb = cb;
    esp_netif_init();
    esp_event_loop_create_default();
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    esp_wifi_init(&cfg);

    esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL, NULL);
    esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, NULL, NULL);

    // Đọc SSID / Pass từ NVS
    nvs_handle_t nvs;
    char saved_ssid[33] = {0};
    char saved_pass[65] = {0};
    char saved_server[128] = {0};
    size_t len_ssid = sizeof(saved_ssid);
    size_t len_pass = sizeof(saved_pass);
    size_t len_srv = sizeof(saved_server);

    if (nvs_open(NVS_NAMESPACE_CONFIG, NVS_READONLY, &nvs) == ESP_OK) {
        nvs_get_str(nvs, NVS_KEY_WIFI_SSID, saved_ssid, &len_ssid);
        nvs_get_str(nvs, NVS_KEY_WIFI_PASS, saved_pass, &len_pass);
        if (nvs_get_str(nvs, NVS_KEY_SERVER_URL, saved_server, &len_srv) == ESP_OK) {
            s_server_url = saved_server;
        }
        nvs_close(nvs);
    }

    if (strlen(saved_ssid) > 0) {
        s_ssid = saved_ssid;
        wifi_config_t wifi_config = {};
        strncpy((char*)wifi_config.sta.ssid, saved_ssid, sizeof(wifi_config.sta.ssid));
        strncpy((char*)wifi_config.sta.password, saved_pass, sizeof(wifi_config.sta.password));
        esp_wifi_set_mode(WIFI_MODE_STA);
        esp_wifi_set_config(WIFI_IF_STA, &wifi_config);
        esp_wifi_start();
    } else {
        ESP_LOGW(TAG, "No Wi-Fi configured, starting SoftAP portal...");
        esp_netif_create_default_wifi_ap();
        wifi_config_t ap_config = {};
        strcpy((char*)ap_config.ap.ssid, "Xiaozhi-Setup");
        strcpy((char*)ap_config.ap.password, WIFI_AP_PASSWORD);
        ap_config.ap.authmode = WIFI_AUTH_WPA2_PSK;
        ap_config.ap.max_connection = 4;

        esp_wifi_set_mode(WIFI_MODE_AP);
        esp_wifi_set_config(WIFI_IF_AP, &ap_config);
        esp_wifi_start();
        start_web_portal();
    }
}

bool WifiManager_IsConnected(void) { return s_connected; }
std::string WifiManager_GetIp(void) { return s_ip_addr; }
std::string WifiManager_GetSsid(void) { return s_ssid; }
int WifiManager_GetRssi(void) {
    wifi_ap_record_t info;
    if (esp_wifi_sta_get_ap_info(&info) == ESP_OK) return info.rssi;
    return -100;
}
std::string WifiManager_GetServerUrl(void) { return s_server_url; }
void WifiManager_SetServerUrl(const std::string& url) { s_server_url = url; }
