#pragma once

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*wifi_event_callback_t)(bool connected, const char* ip);

void WifiManager_Init(wifi_event_callback_t cb);
bool WifiManager_IsConnected(void);
const char* WifiManager_GetIp(void);
const char* WifiManager_GetSsid(void);
int WifiManager_GetRssi(void);

// Đọc / Ghi cấu hình Server riêng
const char* WifiManager_GetServerUrl(void);
void WifiManager_SetServerUrl(const char* url);

// Kiểm tra Wi-Fi đã cấu hình chưa
bool WifiManager_IsConfigured(void);

#ifdef __cplusplus
}
#endif
