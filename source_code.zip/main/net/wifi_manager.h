#pragma once

#include <stdbool.h>
#include <string>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*wifi_event_callback_t)(bool connected, const char* ip);

void WifiManager_Init(wifi_event_callback_t cb);
bool WifiManager_IsConnected(void);
std::string WifiManager_GetIp(void);
std::string WifiManager_GetSsid(void);
int WifiManager_GetRssi(void);

// Đọc / Ghi cấu hình Server riêng
std::string WifiManager_GetServerUrl(void);
void WifiManager_SetServerUrl(const std::string& url);

#ifdef __cplusplus
}
#endif
