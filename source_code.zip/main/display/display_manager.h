#pragma once

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Khởi tạo toàn bộ hệ thống màn hình ILI9341 + Cảm ứng FT6236 + LVGL
bool DisplayManager_Init(void);

// Điều chỉnh độ sáng màn hình qua PWM (0 - 100%)
void DisplayManager_SetBrightness(uint8_t percent);

// Chạy vòng lặp tác vụ LVGL
void DisplayManager_TaskHandler(void);

#ifdef __cplusplus
}
#endif
