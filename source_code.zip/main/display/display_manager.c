#include "display_manager.h"
#include "board_pins.h"
#include "ui/ui_mobile.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_vendor.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_ili9341.h"
#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "driver/i2c.h"
#include "driver/ledc.h"
#include "esp_log.h"
#include "lvgl.h"

static const char* TAG = "DisplayMgr";

static esp_lcd_panel_handle_t s_panel_handle = NULL;
static lv_disp_drv_t s_disp_drv;
static lv_disp_draw_buf_t s_disp_buf;
static lv_color_t* s_buf1 = NULL;
static lv_color_t* s_buf2 = NULL;
static SemaphoreHandle_t s_lvgl_mux = NULL;

#define LVGL_BUFFER_LINES   40

// --- Callback Flush LVGL ra màn hình ---
static bool notify_lvgl_flush_ready(esp_lcd_panel_io_handle_t panel_io, esp_lcd_panel_io_event_data_t *edata, void *user_ctx) {
    lv_disp_drv_t *disp_driver = (lv_disp_drv_t *)user_ctx;
    lv_disp_flush_ready(disp_driver);
    return false;
}

static void lvgl_flush_cb(lv_disp_drv_t *drv, const lv_area_t *area, lv_color_t *color_map) {
    esp_lcd_panel_handle_t panel = (esp_lcd_panel_handle_t)drv->user_data;
    int offsetx1 = area->x1;
    int offsetx2 = area->x2;
    int offsety1 = area->y1;
    int offsety2 = area->y2;
    esp_lcd_panel_draw_bitmap(panel, offsetx1, offsety1, offsetx2 + 1, offsety2 + 1, color_map);
}

// --- Callback Đọc cảm ứng FT6236 ---
static void lvgl_touch_read_cb(lv_indev_drv_t *drv, lv_indev_data_t *data) {
    uint8_t data_raw[5];
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (0x38 << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, 0x02, true); // TD_STATUS reg
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (0x38 << 1) | I2C_MASTER_READ, true);
    i2c_master_read(cmd, data_raw, 5, I2C_MASTER_LAST_NACK);
    i2c_master_stop(cmd);

    esp_err_t ret = i2c_master_cmd_begin(TOUCH_I2C_PORT, cmd, pdMS_TO_TICKS(20));
    i2c_cmd_link_delete(cmd);

    if (ret == ESP_OK && (data_raw[0] & 0x0F) > 0) {
        uint16_t x = ((data_raw[1] & 0x0F) << 8) | data_raw[2];
        uint16_t y = ((data_raw[3] & 0x0F) << 8) | data_raw[4];
        data->point.x = x;
        data->point.y = y;
        data->state = LV_INDEV_STATE_PRESSED;
    } else {
        data->state = LV_INDEV_STATE_RELEASED;
    }
}

// --- Tăng Tick cho LVGL định kỳ ---
static void lvgl_tick_timer_cb(void *arg) {
    lv_tick_inc(2);
}

// --- Tác vụ render LVGL ---
static void lvgl_task(void *pvParameter) {
    ESP_LOGI(TAG, "Starting LVGL task");
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(10));
        if (xSemaphoreTake(s_lvgl_mux, portMAX_DELAY) == pdTRUE) {
            lv_timer_handler();
            xSemaphoreGive(s_lvgl_mux);
        }
    }
}

// ============================================================================
// KHỞI TẠO PHẦN CỨNG
// ============================================================================
bool DisplayManager_Init(void) {
    s_lvgl_mux = xSemaphoreCreateMutex();

    // 1. Cấu hình PWM Backlight (LEDC)
    ledc_timer_config_t ledc_timer = {};
    ledc_timer.speed_mode       = LEDC_LOW_SPEED_MODE;
    ledc_timer.duty_resolution  = LEDC_TIMER_10_BIT;
    ledc_timer.timer_num        = LEDC_TIMER_0;
    ledc_timer.freq_hz          = 5000;
    ledc_timer.clk_cfg          = LEDC_AUTO_CLK;
    ledc_timer_config(&ledc_timer);

    ledc_channel_config_t ledc_channel = {};
    ledc_channel.gpio_num       = LCD_PIN_BACKLIGHT;
    ledc_channel.speed_mode     = LEDC_LOW_SPEED_MODE;
    ledc_channel.channel        = LEDC_CHANNEL_0;
    ledc_channel.intr_type      = LEDC_INTR_DISABLE;
    ledc_channel.timer_sel      = LEDC_TIMER_0;
    ledc_channel.duty           = 800; // ~80%
    ledc_channel.hpoint         = 0;
    ledc_channel_config(&ledc_channel);

    // 2. Khởi tạo SPI Bus cho LCD
    spi_bus_config_t buscfg = {};
    buscfg.mosi_io_num = LCD_PIN_MOSI;
    buscfg.miso_io_num = -1;
    buscfg.sclk_io_num = LCD_PIN_SCLK;
    buscfg.quadwp_io_num = -1;
    buscfg.quadhd_io_num = -1;
    buscfg.max_transfer_sz = LCD_WIDTH * LVGL_BUFFER_LINES * sizeof(lv_color_t);
    ESP_ERROR_CHECK(spi_bus_initialize(LCD_SPI_HOST, &buscfg, SPI_DMA_CH_AUTO));

    esp_lcd_panel_io_handle_t io_handle = NULL;
    esp_lcd_panel_io_spi_config_t io_config = {};
    io_config.cs_gpio_num = LCD_PIN_CS;
    io_config.dc_gpio_num = LCD_PIN_DC;
    io_config.spi_mode = 0;
    io_config.pclk_hz = LCD_PIXEL_CLOCK_HZ;
    io_config.trans_queue_depth = 10;
    io_config.on_color_trans_done = notify_lvgl_flush_ready;
    io_config.user_ctx = &s_disp_drv;
    io_config.lcd_cmd_bits = 8;
    io_config.lcd_param_bits = 8;
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)LCD_SPI_HOST, &io_config, &io_handle));

    // 3. Khởi tạo ILI9341 panel driver
    esp_lcd_panel_dev_config_t panel_config = {};
    panel_config.reset_gpio_num = LCD_PIN_RST;
    panel_config.rgb_endian = LCD_RGB_ENDIAN_BGR;
    panel_config.bits_per_pixel = 16;
    ESP_ERROR_CHECK(esp_lcd_new_panel_ili9341(io_handle, &panel_config, &s_panel_handle));
    ESP_ERROR_CHECK(esp_lcd_panel_reset(s_panel_handle));
    ESP_ERROR_CHECK(esp_lcd_panel_init(s_panel_handle));
    ESP_ERROR_CHECK(esp_lcd_panel_disp_on_off(s_panel_handle, true));

    // 4. Khởi tạo I2C cho Cảm ứng FT6236 (và Codec ES8311)
    i2c_config_t conf = {};
    conf.mode = I2C_MODE_MASTER;
    conf.sda_io_num = TOUCH_PIN_SDA;
    conf.scl_io_num = TOUCH_PIN_SCL;
    conf.sda_pullup_en = GPIO_PULLUP_ENABLE;
    conf.scl_pullup_en = GPIO_PULLUP_ENABLE;
    conf.master.clk_speed = 400000;
    i2c_param_config(TOUCH_I2C_PORT, &conf);
    i2c_driver_install(TOUCH_I2C_PORT, conf.mode, 0, 0, 0);

    // 5. Khởi tạo LVGL
    lv_init();
    s_buf1 = (lv_color_t*)heap_caps_malloc(LCD_WIDTH * LVGL_BUFFER_LINES * sizeof(lv_color_t), MALLOC_CAP_DMA);
    s_buf2 = (lv_color_t*)heap_caps_malloc(LCD_WIDTH * LVGL_BUFFER_LINES * sizeof(lv_color_t), MALLOC_CAP_DMA);
    lv_disp_draw_buf_init(&s_disp_buf, s_buf1, s_buf2, LCD_WIDTH * LVGL_BUFFER_LINES);

    lv_disp_drv_init(&s_disp_drv);
    s_disp_drv.hor_res = LCD_WIDTH;
    s_disp_drv.ver_res = LCD_HEIGHT;
    s_disp_drv.flush_cb = lvgl_flush_cb;
    s_disp_drv.draw_buf = &s_disp_buf;
    s_disp_drv.user_data = s_panel_handle;
    lv_disp_drv_register(&s_disp_drv);

    // Đăng ký Touch Input Device
    static lv_indev_drv_t indev_drv;
    lv_indev_drv_init(&indev_drv);
    indev_drv.type = LV_INDEV_TYPE_POINTER;
    indev_drv.read_cb = lvgl_touch_read_cb;
    lv_indev_drv_register(&indev_drv);

    // Timer tick định kỳ 2ms cho LVGL
    esp_timer_create_args_t tick_timer_args = {};
    tick_timer_args.callback = &lvgl_tick_timer_cb;
    tick_timer_args.name = "lvgl_tick";
    esp_timer_handle_t tick_timer = NULL;
    esp_timer_create(&tick_timer_args, &tick_timer);
    esp_timer_start_periodic(tick_timer, 2000);

    // Tạo Task chạy LVGL
    xTaskCreatePinnedToCore(lvgl_task, "lvgl_task", 4096, NULL, 5, NULL, 1);

    // Khởi tạo giao diện Mobile UI
    xSemaphoreTake(s_lvgl_mux, portMAX_DELAY);
    UiMobile_Init();
    xSemaphoreGive(s_lvgl_mux);

    ESP_LOGI(TAG, "Display and Mobile UI initialized successfully!");
    return true;
}

void DisplayManager_SetBrightness(uint8_t percent) {
    if (percent > 100) percent = 100;
    uint32_t duty = (1023 * percent) / 100;
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
}
