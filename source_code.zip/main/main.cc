#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_log.h"
#include "nvs_flash.h"

#include "board_pins.h"
#include "config.h"
#include "display/display_manager.h"
#include "ui/ui_mobile.h"
#include "audio/es8311_codec.h"
#include "peripherals/relay_controller.h"
#include "peripherals/power_manager.h"
#include "net/wifi_manager.h"
#include "net/websocket_client.h"

static const char* TAG = "MainApp";

// --- Xử lý sự kiện từ Giao diện Mobile UI ---
static void on_ui_mic_clicked(void) {
    ESP_LOGI(TAG, "UI Mic button clicked");
    if (WebSocketClient_IsListening()) {
        WebSocketClient_StopListening();
    } else {
        WebSocketClient_StartListening();
    }
}

static void on_ui_relay_toggled(int relay_idx, bool state) {
    ESP_LOGI(TAG, "Relay %d toggled: %d", relay_idx, state);
    RelayController_Set(relay_idx, state);
}

static void on_ui_volume_changed(int volume) {
    ESP_LOGI(TAG, "Volume changed: %d", volume);
    Es8311_SetVolume((uint8_t)volume);
}

static void on_ui_brightness_changed(int brightness) {
    ESP_LOGI(TAG, "Brightness changed: %d", brightness);
    DisplayManager_SetBrightness((uint8_t)brightness);
}

// --- Callback khi Wi-Fi thay đổi trạng thái ---
static void on_wifi_status_changed(bool connected, const char* ip) {
    UiMobile_SetWifiStatus(connected, WifiManager_GetSsid().c_str(), WifiManager_GetRssi());
    if (connected) {
        ESP_LOGI(TAG, "Wi-Fi connected! Starting WebSocket connection to: %s", WifiManager_GetServerUrl().c_str());
        WebSocketClient_Init(WifiManager_GetServerUrl());
    } else {
        ESP_LOGW(TAG, "Wi-Fi disconnected!");
        UiMobile_SetServerStatus(false, NULL);
    }
}

// --- Tác vụ định kỳ cập nhật đồng hồ và pin trên Status Bar ---
static void system_monitor_task(void *pvParameters) {
    int dummy_minute = 0;
    int dummy_hour = 12;

    while (1) {
        vTaskDelay(pdMS_TO_TICKS(1000));

        // 1. Cập nhật thời gian
        dummy_minute++;
        if (dummy_minute >= 60) {
            dummy_minute = 0;
            dummy_hour = (dummy_hour + 1) % 24;
        }
        UiMobile_SetTime(dummy_hour, dummy_minute);

        // 2. Cập nhật Pin
        int battery = PowerManager_GetBatteryPercentage();
        UiMobile_SetBattery(battery, PowerManager_IsCharging());

        // 3. Cập nhật trạng thái Wi-Fi
        if (WifiManager_IsConnected()) {
            UiMobile_SetWifiStatus(true, WifiManager_GetSsid().c_str(), WifiManager_GetRssi());
        }
    }
}

// ============================================================================
// HÀM CHÍNH APP_MAIN()
// ============================================================================
extern "C" {
    void app_main(void);
}

void app_main(void) {
    ESP_LOGI(TAG, "===============================================");
    ESP_LOGI(TAG, "   XIAOZHI ESP32-S3 OPEN EDITION v2.0 BOOT   ");
    ESP_LOGI(TAG, "   NO DRM - NO EXPIRATION - PRIVATE SERVER    ");
    ESP_LOGI(TAG, "===============================================");

    // 1. Khởi tạo NVS Flash
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    // 2. Khởi tạo Thiết bị Ngoại vi (Relay & Đo pin)
    RelayController_Init();
    PowerManager_Init();

    // 3. Khởi tạo Audio Codec ES8311
    Es8311_Init();

    // 4. Khởi tạo Màn hình ILI9341 + Cảm ứng FT6236 + Giao diện Mobile UI
    DisplayManager_Init();

    // 5. Đăng ký các sự kiện tương tác người dùng
    UiMobile_RegisterMicCallback(on_ui_mic_clicked);
    UiMobile_RegisterRelayCallback(on_ui_relay_toggled);
    UiMobile_RegisterVolumeCallback(on_ui_volume_changed);
    UiMobile_RegisterBrightnessCallback(on_ui_brightness_changed);

    // 6. Khởi động Quản lý Mạng Wi-Fi
    WifiManager_Init(on_wifi_status_changed);

    // 7. Tạo tác vụ định kỳ cập nhật thông tin hệ thống
    xTaskCreatePinnedToCore(system_monitor_task, "sys_mon", 2048, NULL, 1, NULL, 1);

    ESP_LOGI(TAG, "System initialization completed successfully!");
}
