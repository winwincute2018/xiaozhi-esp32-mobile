#pragma once

#include "driver/gpio.h"

/**
 * ============================================================================
 * CẤU HÌNH PHẦN CỨNG BO MẠCH XIAOZHI ESP32-S3 AIO 2.8 INCH
 * (Tương thích với bo mạch XIAOZHI.VN_28aio / JC2432W328 / Guition 2.8")
 * ============================================================================
 */

// 1. CẤU HÌNH MÀN HÌNH LCD (ILI9341 - SPI Interface)
#define LCD_WIDTH               240
#define LCD_HEIGHT              320
#define LCD_PIXEL_CLOCK_HZ      (40 * 1000 * 1000)

#define LCD_SPI_HOST            SPI2_HOST
#define LCD_PIN_MOSI            GPIO_NUM_13
#define LCD_PIN_SCLK            GPIO_NUM_12
#define LCD_PIN_CS              GPIO_NUM_10
#define LCD_PIN_DC              GPIO_NUM_11
#define LCD_PIN_RST             GPIO_NUM_1
#define LCD_PIN_BACKLIGHT       GPIO_NUM_40

// 2. CẤU HÌNH CẢM ỨNG (FT6236 / FT6336 - I2C Interface)
#define TOUCH_I2C_PORT          I2C_NUM_0
#define TOUCH_PIN_SDA           GPIO_NUM_8
#define TOUCH_PIN_SCL           GPIO_NUM_9
#define TOUCH_PIN_INT           GPIO_NUM_3
#define TOUCH_PIN_RST           GPIO_NUM_NC

// 3. CẤU HÌNH AUDIO CODEC (ES8311 - I2C Điều khiển + I2S Duplex)
#define ES8311_I2C_PORT         I2C_NUM_0       // Dùng chung bus I2C với Touch
#define ES8311_I2C_ADDR         0x18            // Địa chỉ I2C của ES8311

#define I2S_PORT_NUM            I2S_NUM_0
#define I2S_PIN_MCLK            GPIO_NUM_2
#define I2S_PIN_BCLK            GPIO_NUM_14
#define I2S_PIN_WS              GPIO_NUM_15     // LRCK
#define I2S_PIN_DOUT            GPIO_NUM_16     // Loa (Speaker playback)
#define I2S_PIN_DIN             GPIO_NUM_17     // Micro (Mic recording)

#define AUDIO_SAMPLE_RATE       16000
#define AUDIO_BITS_PER_SAMPLE   16
#define AUDIO_CHANNELS          1

// 4. CẤU HÌNH THIẾT BỊ NGOẠI VI (RELAYS & NGUỒN)
#define RELAY_1_PIN             GPIO_NUM_4      // Relay 1 (Đèn)
#define RELAY_2_PIN             GPIO_NUM_5      // Relay 2 (Quạt)
#define RELAY_3_PIN             GPIO_NUM_21     // Relay 3 (Thiết bị phụ)

#define BATTERY_ADC_CHANNEL     ADC_CHANNEL_0   // GPIO 1 - Đo điện áp pin
#define BUTTON_BOOT_PIN         GPIO_NUM_0      // Nút BOOT vật lý
#define LED_STATUS_PIN          GPIO_NUM_38     // LED báo trạng thái
