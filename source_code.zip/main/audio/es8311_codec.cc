#include "es8311_codec.h"
#include "board_pins.h"

#include <string.h>
#include "driver/i2c.h"
#include "driver/i2s_std.h"
#include "esp_log.h"

static const char* TAG = "ES8311";

static i2s_chan_handle_t s_tx_chan = NULL;
static i2s_chan_handle_t s_rx_chan = NULL;

static esp_err_t es8311_write_reg(uint8_t reg, uint8_t val) {
    uint8_t buf[2] = {reg, val};
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (ES8311_I2C_ADDR << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write(cmd, buf, sizeof(buf), true);
    i2c_master_stop(cmd);
    esp_err_t ret = i2c_master_cmd_begin(ES8311_I2C_PORT, cmd, pdMS_TO_TICKS(50));
    i2c_cmd_link_delete(cmd);
    return ret;
}

bool Es8311_Init(void) {
    ESP_LOGI(TAG, "Initializing ES8311 Codec...");

    // 1. Cấu hình thanh ghi ES8311 qua I2C
    es8311_write_reg(0x00, 0x80); // Reset
    vTaskDelay(pdMS_TO_TICKS(20));
    es8311_write_reg(0x00, 0x00); // Wake up
    es8311_write_reg(0x01, 0x30); // Clock on
    es8311_write_reg(0x02, 0x00); // Master mode = false (Slave)
    es8311_write_reg(0x03, 0x10); // ADC clock
    es8311_write_reg(0x04, 0x10); // DAC clock
    es8311_write_reg(0x05, 0x00); // Sample rate divider
    es8311_write_reg(0x0B, 0x00); // System power up
    es8311_write_reg(0x0C, 0x00); // System power up
    es8311_write_reg(0x10, 0x00); // ADC power up
    es8311_write_reg(0x11, 0x7F); // ADC PGA gain
    es8311_write_reg(0x12, 0x00); // ADC digital volume
    es8311_write_reg(0x13, 0x10); // ALC power on
    es8311_write_reg(0x14, 0x1A); // ADC volume max
    es8311_write_reg(0x17, 0xBF); // DAC volume
    es8311_write_reg(0x1D, 0x02); // Enable DAC to HP
    es8311_write_reg(0x31, 0x40); // DAC power on
    es8311_write_reg(0x32, 0x00); // DAC unmute

    // 2. Cấu hình I2S Duplex Channel (I2S_NUM_0)
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_PORT_NUM, I2S_ROLE_MASTER);
    ESP_ERROR_CHECK(i2s_new_channel(&chan_cfg, &s_tx_chan, &s_rx_chan));

    i2s_std_config_t std_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(AUDIO_SAMPLE_RATE),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO),
        .gpio_cfg = {
            .mclk = I2S_PIN_MCLK,
            .bclk = I2S_PIN_BCLK,
            .ws   = I2S_PIN_WS,
            .dout = I2S_PIN_DOUT,
            .din  = I2S_PIN_DIN,
            .invert_flags = {
                .mclk_inv = false,
                .bclk_inv = false,
                .ws_inv   = false,
            },
        },
    };

    ESP_ERROR_CHECK(i2s_channel_init_std_mode(s_tx_chan, &std_cfg));
    ESP_ERROR_CHECK(i2s_channel_init_std_mode(s_rx_chan, &std_cfg));

    ESP_ERROR_CHECK(i2s_channel_enable(s_tx_chan));
    ESP_ERROR_CHECK(i2s_channel_enable(s_rx_chan));

    Es8311_SetVolume(75);
    ESP_LOGI(TAG, "ES8311 Codec initialized successfully!");
    return true;
}

void Es8311_SetVolume(uint8_t volume) {
    if (volume > 100) volume = 100;
    // Thanh ghi 0x32 trong ES8311: 0 = 0dB (max), 0xFF = mute
    uint8_t reg_val = (uint8_t)((100 - volume) * 2.55f);
    es8311_write_reg(0x32, reg_val);
}

int Es8311_Read(int16_t* buffer, size_t samples) {
    size_t bytes_read = 0;
    esp_err_t ret = i2s_channel_read(s_rx_chan, buffer, samples * sizeof(int16_t), &bytes_read, pdMS_TO_TICKS(100));
    if (ret != ESP_OK) return 0;
    return bytes_read / sizeof(int16_t);
}

int Es8311_Write(const int16_t* buffer, size_t samples) {
    size_t bytes_written = 0;
    esp_err_t ret = i2s_channel_write(s_tx_chan, buffer, samples * sizeof(int16_t), &bytes_written, pdMS_TO_TICKS(100));
    if (ret != ESP_OK) return 0;
    return bytes_written / sizeof(int16_t);
}
