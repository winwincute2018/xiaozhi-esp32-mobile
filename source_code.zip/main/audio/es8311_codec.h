#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// Khởi tạo ES8311 Audio Codec (I2C cấu hình + I2S Duplex)
bool Es8311_Init(void);

// Đặt âm lượng loa (0 - 100%)
void Es8311_SetVolume(uint8_t volume);

// Đọc âm thanh từ Micro (PCM 16kHz 16-bit Mono)
int Es8311_Read(int16_t* buffer, size_t samples);

// Phát âm thanh ra Loa
int Es8311_Write(const int16_t* buffer, size_t samples);

#ifdef __cplusplus
}
#endif
