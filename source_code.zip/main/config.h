#pragma once

#include <string>

/**
 * ============================================================================
 * CẤU HÌNH HỆ THỐNG XIAOZHI CHATBOT (OPEN EDITION - KHÔNG GIỚI HẠN)
 * ============================================================================
 */

#define FW_VERSION                  "v2.0-OpenEdition"
#define FW_AUTHOR                   "Xiaozhi Clean OS"

// Cấu hình Wi-Fi dự phòng (Khi chưa cấu hình mạng)
#define WIFI_AP_SSID_PREFIX         "Xiaozhi-AI-"
#define WIFI_AP_PASSWORD            "12345678"
#define WIFI_CONFIG_PORTAL_IP       "192.168.4.1"

// Cấu hình Server riêng mặc định (Người dùng có thể đổi qua Web UI)
#define DEFAULT_WS_SERVER_URL       "ws://192.168.1.100:8000/ws"
#define DEFAULT_OTA_SERVER_URL      "http://192.168.1.100:8000/ota/"

// NVS Keys
#define NVS_NAMESPACE_CONFIG        "xz_config"
#define NVS_KEY_WIFI_SSID           "wifi_ssid"
#define NVS_KEY_WIFI_PASS           "wifi_pass"
#define NVS_KEY_SERVER_URL          "server_url"
#define NVS_KEY_OTA_URL             "ota_url"
#define NVS_KEY_VOLUME              "volume"
#define NVS_KEY_BRIGHTNESS          "brightness"

// Tham số âm thanh
#define OPUS_FRAME_DURATION_MS      60
#define OPUS_FRAME_SIZE             (AUDIO_SAMPLE_RATE * OPUS_FRAME_DURATION_MS / 1000)
